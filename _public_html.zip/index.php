<?php
/*This PHP code manages login for users and admins in a library system.
It checks email and password and sends the user to right page after a successful login.
Different database tables are used for users and admins.

Interface was built using Bootstrap, and visual design was enhanced with CSS and JavaScript.
 */
session_start();
require_once "config.php";
/*Start PHP session and includes  database connection file.*/

$email = $password = "";
$email_err = $password_err = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (empty(trim($_POST["email"]))) {
        $email_err = "Please enter your email.";
    } else {
        $email = trim($_POST["email"]);
    }

    if (empty(trim($_POST["password"]))) {
        $password_err = "Please enter your password.";
    } else {
        $password = trim($_POST["password"]);
    }
    /*Used to check for missing or empty values in user login form. */
    if (empty($email_err) && empty($password_err)) {
        if (isset($_POST["admin_login"])) {
            // Control Admins table
            $sql = "SELECT id, email, admin_password FROM Admins WHERE email = ?";
        } else {
            // Control Users table
            $sql = "SELECT id, email, user_password FROM Users WHERE email = ?";
        }
        /*Used to determine role (admin or user) from which user is trying to log in. */
        if ($stmt = mysqli_prepare($link, $sql)) {
            mysqli_stmt_bind_param($stmt, "s", $param_email);
            $param_email = $email;

            if (mysqli_stmt_execute($stmt)) {
                mysqli_stmt_store_result($stmt);

                if (mysqli_stmt_num_rows($stmt) == 1) {
                    mysqli_stmt_bind_result($stmt, $id, $email, $db_password);

                    if (mysqli_stmt_fetch($stmt)) {
                    if ($password === $db_password) { // Şifre kontrolü
    $_SESSION["id"] = $id;
    $_SESSION["email"] = $email;

    if (isset($_POST["admin_login"])) {
        $_SESSION["admin_id"] = $id; // Admin oturumu için ekleniyor
        // Admin sayfasına yönlendirme
        header("location: admin_page.php");
    } else {
        // User sayfasına yönlendirme
        header("location: home_page.php");
    }
    exit();
}
 else {
                            $password_err = "Invalid password.";
                        }
                    }
                } else {
                    $email_err = "No account found with that email.";
                }
                /*Provides database query execution and redirection with session information. */
            } else {
                echo "Oops! Something went wrong. Please try again later.";
            }

            mysqli_stmt_close($stmt);
        }
    }
    mysqli_close($link);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        html, body {
            height: 100%;
            margin: 0;
            padding: 0;
            overflow: hidden;
        }
        body {
            display: flex;
            justify-content: center;
            align-items: center;
            background: #f0f0f0;
        }
        .container {
            display: flex;
            justify-content: space-between;
            align-items: center;
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
            width: 90%;
            height: 90%;
            max-width: 1200px;
            position: relative;
        }
        .image-section {
            width: 40%;
            height: 100%;
            padding-right: 20px;
        }
        .image-section img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            border-radius: 10px;
        }
        .btn-primary {
            background-color: #bd4934;
            border-color: #bd4934;
        }
        .btn-primary:hover {
            background-color: #a63c2d;
            border-color: #a63c2d;
        }
        .btn-secondary {
            background-color: #6c757d;
            border-color: #6c757d;
        }
        .btn-secondary:hover {
            background-color: #5a6268;
            border-color: #545b62;
        }
        .btn-gold {
            background-color: #ffc107;
            border-color: #ffc107;
            color: black;
        }
        .btn-gold:hover {
            background-color: #e0a800;
            border-color: #d39e00;
            color: black;
        }
        .form-section {
            width: 55%;
            height: 100%;
            position: relative;
            display: flex;
            flex-direction: column;
            justify-content: center;
        }
        .button-group {
            display: flex;
            justify-content: center;
            gap: 10px;
        }
        .welcome-text {
            position: absolute;
            top: 20px;
            left: 50%;
            transform: translate(-50%, 0);
            background-color: #bd4934;
            color: white;
            padding: 15px 30px;
            border-radius: 5px;
            font-family: "Brush Script MT", cursive;
            font-weight: bold;
            font-size: 2.5rem;
            white-space: nowrap;
        }
        .new-year-text {
            position: absolute;
            top: 2px;
            right: 11px;
            color: #bd4934;
            font-size: 1.5rem;
            font-family: "Brush Script MT", cursive;
            font-weight: bold;
        }
        /* Kar taneleri için stil */
        .snowflake {
        position: fixed;
        top: -10px;
        font-size: 1rem;
        color: white;
        opacity: 0.9;
        animation: fall linear infinite;
        text-shadow: 0 0 10px rgba(255, 255, 255, 0.9), 0 0 20px rgba(255, 255, 255, 0.7);
    }

    @keyframes fall {
        0% {
            transform: translateY(0) rotate(0deg);
            opacity: 1;
        }
        100% {
            transform: translateY(100vh) rotate(360deg);
            opacity: 0.8;
        }
    }

    @keyframes sway {
        0%, 100% {
            transform: translateX(0);
        }
        50% {
            transform: translateX(20px);
        }
    }
    </style>
</head>
<body>
    <div class="container">
        <div class="image-section">
            <img src="/images/Login image.jpg" alt="Login Image">
        </div>
        <div class="form-section">
            <div class="welcome-text">Welcome to Book Nest</div>
            <h2 class="text-center">Login</h2>
            <p class="text-center">Please fill in your credentials to login.</p>
            <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
                <div class="mb-3">
                    <label for="email" class="form-label">Email</label>
                    <input type="email" name="email" id="email" class="form-control <?php echo (!empty($email_err)) ? 'is-invalid' : ''; ?>" value="<?php echo $email; ?>">
                    <div class="invalid-feedback"><?php echo $email_err; ?></div>
                </div>
                <div class="mb-3">
                    <label for="password" class="form-label">Password</label>
                    <input type="password" name="password" id="password" class="form-control <?php echo (!empty($password_err)) ? 'is-invalid' : ''; ?>">
                    <div class="invalid-feedback"><?php echo $password_err; ?></div>
                </div>
                <div class="button-group">
                    <button type="submit" class="btn btn-primary" name="user_login">User Login</button>
                    <button type="submit" class="btn btn-secondary" name="admin_login">Admin Login</button>
                    <a href="signup_page.php" class="btn btn-gold">Sign up</a>
                </div>
            </form>
            <!--It is form that user users to login.-->
        </div>
        <div class="new-year-text">Happy New Year</div>
    </div>

    <!-- Kar taneleri -->
    <script>
        const createSnowflake = () => {
            const snowflake = document.createElement('div');
            snowflake.className = 'snowflake';
            snowflake.textContent = '❄';

            snowflake.style.left = Math.random() * 150 + 'vw';
            snowflake.style.animationDuration = Math.random() * 7 + 4 + 's';
            snowflake.style.fontSize = Math.random() * 7 + 8 + 'px';
            document.body.appendChild(snowflake);

            setTimeout(() => {
                snowflake.remove();
            }, 5000);
        };

        setInterval(createSnowflake, 100);
    </script>
</body>
</html>












