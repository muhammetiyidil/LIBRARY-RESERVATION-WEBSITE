<?php
/* User verification is handled in the form, and errors are displayed.
System prevents reuse of email addresses.
It saves user information in database and redirects the user to login page after recording.
*/
require_once "config.php";

$first_name = $last_name = $email = $user_password = $confirm_password = "";
$first_name_err = $last_name_err = $email_err = $user_password_err = $confirm_password_err = "";


if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Check if the first name is empty
    if (empty(trim($_POST["first_name"]))) {
        $first_name_err = "Please enter your first name.";
    } else {
        // Store the first name after trimming any spaces
        $first_name = trim($_POST["first_name"]);
    }
    // Check if the last name is empty
    if (empty(trim($_POST["last_name"]))) {
        $last_name_err = "Please enter your last name.";
    } else {
        // Store the last name after trimming any spaces
        $last_name = trim($_POST["last_name"]);
    }

// Check if the email is empty or if it has an invalid format
    if (empty(trim($_POST["email"]))) {
        $email_err = "Please enter an email.";
    } elseif (!filter_var(trim($_POST["email"]), FILTER_VALIDATE_EMAIL)) {
        $email_err = "Invalid email format.";
    } else {
        // Prepare an SQL query to check if the email already exists in the database
        $sql = "SELECT id FROM Users WHERE email = ?";

        if ($stmt = mysqli_prepare($link, $sql)) {
            mysqli_stmt_bind_param($stmt, "s", $param_email);
            
            // Bind the email parameter
            $param_email = trim($_POST["email"]);
            
            // Execute the SQL query
            if (mysqli_stmt_execute($stmt)) {
                mysqli_stmt_store_result($stmt);
                
                 // Check if the email already exists
                if (mysqli_stmt_num_rows($stmt) == 1) {
                    $email_err = "This email is already taken.";
                } else {
                    // Store the valid email
                    $email = trim($_POST["email"]);
                }
            } else {
                echo "Oops! Something went wrong. Please try again later.";
            }

            mysqli_stmt_close($stmt);
        }
    }

    if (empty(trim($_POST["user_password"]))) {
        $user_password_err = "Please enter a password.";
    } elseif (strlen(trim($_POST["user_password"])) < 6) {
        $user_password_err = "Password must have at least 6 characters.";
    } else {
        // Store the password
        $user_password = trim($_POST["user_password"]);
    }
    
     // Check if the password is empty or less than 6 characters
    if (empty(trim($_POST["confirm_password"]))) {
        $confirm_password_err = "Please confirm the password.";
    } else {
        // Check if the confirm password is empty or doesn't match the entered password
        $confirm_password = trim($_POST["confirm_password"]);
        if (empty($user_password_err) && ($user_password != $confirm_password)) {
            $confirm_password_err = "Password did not match.";
        }
    }

/* Code validates inputs provided by user.
It returns error messages if there are issues with email, password, or other fields.
It checks email against database and shows an error if email is already in use.
*/

    // If no errors are present, insert user data to database
    if (empty($first_name_err) && empty($last_name_err) && empty($email_err) && empty($user_password_err) && empty($confirm_password_err)) {
        $sql = "INSERT INTO Users (first_name, last_name, email, user_password) VALUES (?, ?, ?, ?)";

        if ($stmt = mysqli_prepare($link, $sql)) {
            // Bind parameters to SQL query
            mysqli_stmt_bind_param($stmt, "ssss", $param_first_name, $param_last_name, $param_email, $param_user_password);
            
            // Assign form values to parameters
            $param_first_name = $first_name;
            $param_last_name = $last_name;
            $param_email = $email;
            $param_user_password = $user_password;
            
            // Execute query and check if successful
            if (mysqli_stmt_execute($stmt)) {
                // Set session variables and redirect to login page
                $_SESSION["id"] = mysqli_insert_id($link); 
                $_SESSION["email"] = $email;
                header("location: index.php");
                exit;
            }
             else {
                echo "Something went wrong. Please try again later.";
            }

            mysqli_stmt_close($stmt);
        }
    }

    mysqli_close($link);
}
/* Code saves user's information to database.
If recording is successful, it directs user to login_page.php.
*/
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sign Up</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            display: flex;
            justify-content: center; /* Centers items horizontally */
            align-items: center; /* Centers items vertically */
            min-height: 100vh; /* Ensures the container takes at least the full viewport height */  
            background: #f0f0f0;
        }
        .container {
            display: flex; /* Enables flexbox layout */
            justify-content: space-between; /* Distribute space evenly between child elements */
            align-items: center; /* Align child elements vertically at center */
            background: white;
            padding: 20px; /* Adds space inside the element */
            border-radius: 10px; /* Rounded corners of element */
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2); /* Adds a soft shadow around element */
        }
        .image-section {
            width: 40%;
            padding-right: 20px;
        }
        .image-section img {
            width: 100%;
            border-radius: 10px;
        }
        .btn-primary {
            background-color: #bd4934;
            border-color: #bd4934;
        }
        .btn-primary:hover {
            background-color: #a63c2d;
            border-color: #a63c2d;
        }
        .form-section {
            width: 55%;
        }
         .snowflake {
        position: fixed;
        top: -10px;
        font-size: 1rem;
        color: white;
        opacity: 0.9;
        animation: fall linear infinite;
        text-shadow: 0 0 10px rgba(255, 255, 255, 0.9), 0 0 20px rgba(255, 255, 255, 0.7);
    }

    @keyframes fall {
        0% {
            transform: translateY(0) rotate(0deg);
            opacity: 1;
        }
        100% {
            transform: translateY(100vh) rotate(360deg);
            opacity: 0.8;
        }
    }

    @keyframes sway {
        0%, 100% {
            transform: translateX(0);
        }
        50% {
            transform: translateX(20px);
        }
    }
    </style>
</head>
<body>
    <div class="container">
        <div class="image-section">
        <img src="/images/signupimage.jpg" alt="Signup Image">

        </div>
        <div class="form-section">
    <h2 class="text-center">Sign Up</h2>
    <p class="text-center">Please fill this form to create an account.</p>
    <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
        <div class="mb-3">
            <label for="first_name" class="form-label">First Name</label>
            <input type="text" name="first_name" id="first_name" class="form-control <?php echo (!empty($first_name_err)) ? 'is-invalid' : ''; ?>" value="<?php echo $first_name; ?>">
            <div class="invalid-feedback"><?php echo $first_name_err; ?></div>
        </div>
        <div class="mb-3">
            <label for="last_name" class="form-label">Last Name</label>
            <input type="text" name="last_name" id="last_name" class="form-control <?php echo (!empty($last_name_err)) ? 'is-invalid' : ''; ?>" value="<?php echo $last_name; ?>">
            <div class="invalid-feedback"><?php echo $last_name_err; ?></div>
        </div>
        <div class="mb-3">
            <label for="email" class="form-label">Email</label>
            <input type="email" name="email" id="email" class="form-control <?php echo (!empty($email_err)) ? 'is-invalid' : ''; ?>" value="<?php echo $email; ?>">
            <div class="invalid-feedback"><?php echo $email_err; ?></div>
        </div>
        <div class="mb-3">
            <label for="user_password" class="form-label">Password</label>
            <input type="password" name="user_password" id="user_password" class="form-control <?php echo (!empty($user_password_err)) ? 'is-invalid' : ''; ?>">
            <div class="invalid-feedback"><?php echo $user_password_err; ?></div>
        </div>
        <div class="mb-3">
            <label for="confirm_password" class="form-label">Confirm Password</label>
            <input type="password" name="confirm_password" id="confirm_password" class="form-control <?php echo (!empty($confirm_password_err)) ? 'is-invalid' : ''; ?>">
            <div class="invalid-feedback"><?php echo $confirm_password_err; ?></div>
        </div>
        <div class="text-center">
            <button type="submit" class="btn btn-primary">Sign up</button>
            <a href="index.php" class="btn btn-secondary">Back to Login</a>
        </div>
    </form>
</div>

    </div>
     <script>
        const createSnowflake = () => {
            const snowflake = document.createElement('div');
            snowflake.className = 'snowflake';
            snowflake.textContent = '❄';

            snowflake.style.left = Math.random() * 150 + 'vw';
            snowflake.style.animationDuration = Math.random() * 7 + 4 + 's';
            snowflake.style.fontSize = Math.random() * 6 + 8 + 'px';
            document.body.appendChild(snowflake);

            setTimeout(() => {
                snowflake.remove();
            }, 5000);
        };

        setInterval(createSnowflake, 100);
    </script>
</body>
</html>

