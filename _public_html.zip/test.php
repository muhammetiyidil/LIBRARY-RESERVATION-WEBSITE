<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<?php
$link = mysqli_connect("localhost", "root", "root", "LIBRARY");

if ($link === false) {
    die("ERROR: Could not connect. " . mysqli_connect_error());
}

$sql = "ALTER TABLE users
add column book_ids TEXT";

if (mysqli_query($link, $sql)) {
    echo "Table modified successfully.";
} else {
    echo "ERROR: Could not execute $sql. " . mysqli_error($link);
}


mysqli_close($link);
?>

</body>
</html>