<?php
/*This PHP code creates an admin panel for the library system.
Admin can add, edit and delete books.
All books are listed in card form.

Design was created with Bootstrap and development
with CSS.
 */

session_start();

if (!isset($_SESSION["admin_id"])) {
    header("location: index.php");
    exit;
}
/* Admin session is checked. If there is no session, it directs to login_page.
*/
require_once "config.php";

$message = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST["add_book"])) {
        $book_name = mysqli_real_escape_string($link, $_POST["book_name"]);
        $author = mysqli_real_escape_string($link, $_POST["author"]);
        $page_no = (int)$_POST["page_no"];

        $sql = "INSERT INTO Books (book_name, author, page_no, reserved) VALUES ('$book_name', '$author', $page_no, 0)";
        if (mysqli_query($link, $sql)) {
            $message = "Book added successfully!";
        } else {
            $message = "Error adding book: " . mysqli_error($link);
        }
    }
    
    /* Takes form data to add a new book and saves it to database.
 */

    if (isset($_POST["delete_book_id"])) {
        $book_id = (int)$_POST["delete_book_id"];

        $sql = "DELETE FROM Books WHERE id = $book_id";
        if (mysqli_query($link, $sql)) {
            $message = "Book deleted successfully!";
        } else {
            $message = "Error deleting book: " . mysqli_error($link);
        }
    }
      /* Deletes selected book from database based on its book ID.
*/

    if (isset($_POST["update_book"])) {
        $book_id = (int)$_POST["book_id"];
        $book_name = mysqli_real_escape_string($link, $_POST["book_name"]);
        $author = mysqli_real_escape_string($link, $_POST["author"]);
        $page_no = (int)$_POST["page_no"];

        $sql = "UPDATE Books SET book_name = '$book_name', author = '$author', page_no = $page_no WHERE id = $book_id";
        if (mysqli_query($link, $sql)) {
            $message = "Book updated successfully!";
        } else {
            $message = "Error updating book: " . mysqli_error($link);
        }
    }
     /* Retrieve form data for edit book information and update database.
*/
}
       $sql = "SELECT id, book_name, author, page_no, reserved FROM Books";
       $result = mysqli_query($link, $sql);
        ?>

       <?php
      mysqli_close($link);
         /* Retrieves information of all books from database and list them in form of cards.
 */
      ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Panel</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background: #f9f9f9;
        }
        .app-bar {
            background-color: #bd4934;
            color: white;
            padding: 10px 20px;
            display: flex;
            justify-content: space-between; /* Items are evenly spaced. */
            align-items: center; /* Items are aligned vertically at center of container */
        }
        .app-bar a {
            color: white;
            text-decoration: none;
        }
        .container {
            margin-top: 20px;
        }
        .btn-primary {
             background-color: #e0a800;
            border-color: #e0a800;
        }
        .btn-secondary {
           background-color: #007bff;
            border-color: #007bff;
        }
        
        .btn-danger {
            background-color: #bd4934;
            border-color: #bd4934;
        }
         .fixed-image {
            position: fixed;
            top: 60px;
            right: 20px;
            width: 325px; 
            border-radius: 10px; /* Rounded corners of element */
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1); /* Adds a soft shadow around element */
        }
        .row {
            display: flex;
            flex-wrap: wrap;
            justify-content: flex-start; /* Aligns cards to the left */
            gap: 5px; /* Space between cards */
        }

        .col {
            flex: 0 0 43%;
            max-width: 43%; 
        }

        .container {
            margin-right: 370px;
            margin-left: 25px;
        }
    </style>
</head>
<body>
    <div class="app-bar">
        <span>Book Nest Admin Panel</span>
        <a href="index.php">Log out</a>
    </div>
    <div class="container">
        <h2>Manage Books</h2>

        <?php if (!empty($message)): ?>
            <div class="alert alert-info"><?php echo $message; ?></div>
        <?php endif; ?>

        <form method="post" class="mb-4">
    <div class="row g-3">
        <div class="col-md-4">
            <input type="text" name="book_name" class="form-control" placeholder="Book Name" required>
        </div>
        <div class="col-md-4">
            <input type="text" name="author" class="form-control" placeholder="Author" required>
        </div>
        <div class="col-md-2">
            <input type="number" name="page_no" class="form-control" placeholder="Pages" required>
        </div>
        <div class="col-md-11 d-flex justify-content-center">
            <button type="submit" name="add_book" class="btn btn-primary">Add Book</button>
        </div>
    </div>
</form>


        <div class="row">
            <?php while ($book = mysqli_fetch_assoc($result)): ?>
                <div class="col">
                    <div class="card">
                        <div class="card-body">
                            <form method="post">
                                <input type="hidden" name="book_id" value="<?php echo $book["id"]; ?>">
                                <div class="mb-3">
                                    <label for="book_name_<?php echo $book["id"]; ?>">Name</label>
                                    <input type="text" id="book_name_<?php echo $book["id"]; ?>" name="book_name" class="form-control" value="<?php echo htmlspecialchars($book["book_name"]); ?>" required>
                                </div>
                                <div class="mb-3">
                                    <label for="author_<?php echo $book["id"]; ?>">Author</label>
                                    <input type="text" id="author_<?php echo $book["id"]; ?>" name="author" class="form-control" value="<?php echo htmlspecialchars($book["author"]); ?>" required>
                                </div>
                                <div class="mb-3">
                                    <label for="page_no_<?php echo $book["id"]; ?>">Pages</label>
                                    <input type="number" id="page_no_<?php echo $book["id"]; ?>" name="page_no" class="form-control" value="<?php echo $book["page_no"]; ?>" required>
                                </div>
                                <div class="mt-3">
                                    <button type="submit" name="update_book" class="btn btn-secondary">Update</button>
                                    <button type="submit" name="delete_book_id" value="<?php echo $book["id"]; ?>" class="btn btn-danger">Delete</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            <?php endwhile; ?>
            <!-- Books are displayed in a card format, each with edit and delete buttons.-->
        </div>
    </div>
    <!--Adds a still image to right.-->
    <img src="/images/13472b866404dbf8b71d1e9183b40801.jpg" alt="Sidebar Image" class="fixed-image">
</body>
</html>