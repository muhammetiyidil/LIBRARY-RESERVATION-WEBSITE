<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    insert
<?php
$link = mysqli_connect("localhost", "u679098418_root", "Root123456*", "u679098418_LIBRARY");

if ($link === false) {
    die("ERROR: Could not connect. " . mysqli_connect_error());
}
$sql = "INSERT INTO Admins (first_name, last_name, email, admin_password) VALUES
('Muhammet','İyidil','muhammetiyidil@gmail.com','123456'),
('Beyza','Yıldırım','beyzayildirim@gmail.com','123456')";

if (mysqli_query($link, $sql)) {
    echo "Records added successfully.";
} else {
    echo "ERROR: Could not able to execute $sql. " . mysqli_error($link);
}

mysqli_close($link);

/*This PHP code connects to MySQL database, inserts multiple records to admins table, displays a success or
error message and closes connection.*/
?>
</body>
</html>