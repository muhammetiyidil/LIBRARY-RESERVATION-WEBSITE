<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<?php

$link = mysqli_connect("localhost", "u679098418_root", "Root123456*", "u679098418_LIBRARY");

if ($link === false) {
    die("ERROR: Could not connect. " . mysqli_connect_error());
}

$sql = "INSERT INTO Books (book_name, author, page_no, reserved) VALUES
    ('To Kill a Mockingbird', 'Harper Lee', 281, FALSE),
    ('1984', 'George Orwell', 328, FALSE),
    ('The Great Gatsby', 'F. Scott Fitzgerald', 180, FALSE),
    ('The Catcher in the Rye', 'J.D. Salinger', 214, FALSE),
    ('Moby Dick', 'Herman Melville', 635, FALSE),
    ('Pride and Prejudice', 'Jane Austen', 279, FALSE),
    ('War and Peace', 'Leo Tolstoy', 1225, FALSE),
    ('The Hobbit', 'J.R.R. Tolkien', 310, FALSE),
    ('Crime and Punishment', 'Fyodor Dostoevsky', 671, FALSE),
    ('The Adventures of Sherlock Holmes', 'Arthur Conan Doyle', 307, FALSE),
    ('Brave New World', 'Aldous Huxley', 268, FALSE),
    ('The Odyssey', 'Homer', 541, FALSE),
    ('Frankenstein', 'Mary Shelley', 280, FALSE),
    ('The Divine Comedy', 'Dante Alighieri', 798, FALSE),
    ('The Brothers Karamazov', 'Fyodor Dostoevsky', 824, FALSE),
    ('Jane Eyre', 'Charlotte Bronte', 500, FALSE),
    ('Wuthering Heights', 'Emily Bronte', 416, FALSE),
    ('The Iliad', 'Homer', 704, FALSE),
    ('Dracula', 'Bram Stoker', 418, FALSE),
    ('Anna Karenina', 'Leo Tolstoy', 864, FALSE)";

if (mysqli_query($link, $sql)) {
    echo "Records added successfully.";
} else {
    echo "ERROR: Could not able to execute $sql. " . mysqli_error($link);
}

mysqli_close($link);
/* This PHP code connects to MySQL database, inserts multiple records to books table, displays a success or
error message and closes connection.*/
?>
</body>
</html>