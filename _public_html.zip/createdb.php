<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<?php

$link = mysqli_connect("localhost", "u679098418_root", "Root123456*");

if($link === false){
 die("ERROR: Could not connect. " . mysqli_connect_error());
}

$sql = "CREATE DATABASE u679098418_LIBRARY";
if(mysqli_query($link, $sql)){
 echo "Database created successfully";
} else{
 echo "Database doesn't created $sql. " . mysqli_error($link);
 
 /* This PHP code connects to MySQL, creates a database, handles errors, and closes connection. */
}

mysqli_close($link);
?>
</body>
</html>