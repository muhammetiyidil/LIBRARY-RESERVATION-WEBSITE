<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<?php
$link = mysqli_connect("localhost", "u679098418_root", "Root123456*", "u679098418_LIBRARY");

if($link === false){
 die("ERROR: Could not connect. " . mysqli_connect_error());
}

$sql = "CREATE TABLE Books(
 id INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
 book_name VARCHAR(200) NOT NULL,
 author VARCHAR(30) NOT NULL,
 page_no INT NOT NULL,
 reserved BOOLEAN DEFAULT TRUE  
)";
if(mysqli_query($link, $sql)){
    echo "Table created successfully.";
   } else{
    echo "Table doesn't created successfully $sql. " . mysqli_error($link);
   }
   mysqli_close($link);
   
   /* This PHP code connects to MySQL database, creates a table for books, handles errors,
   and closes connection. */
   ?>
</body>
</html>