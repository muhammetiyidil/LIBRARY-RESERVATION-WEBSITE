<?php
/* This PHP code allows users to reserve books.
All books are listed with a "Reserve" button for available ones.
Database is updated when a book is reserved.
*/
session_start();

if (!isset($_SESSION["id"])) {
    header("location: index.php");
    exit;
    /* User session is checked. If there is no session, it directs to login_page.
*/
}

else if (!isset($_SESSION["id"])) {
    header("location: signup_page.php");
    exit;
}

require_once "config.php";

$user_id = $_SESSION["id"];

// Fetch books from the database
$sql = "SELECT id, book_name, author, page_no, reserved FROM Books";
$result = mysqli_query($link, $sql);

/* Retrieves book information from database and lists it
*/

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST["reserve_book_id"])) {
        $book_id = (int)$_POST["reserve_book_id"];

        // Check if the book is already reserved
        $check_sql = "SELECT reserved FROM Books WHERE id = $book_id";
        $check_result = mysqli_query($link, $check_sql);
        $book = mysqli_fetch_assoc($check_result);

        if ($book && !$book["reserved"]) {
            // Mark book as reserved
            $update_sql = "UPDATE Books SET reserved = 1 WHERE id = $book_id";
            mysqli_query($link, $update_sql);

            // Update user table with reserved book id
            $user_sql = "UPDATE Users SET book_ids = CONCAT(IFNULL(book_ids, ''), '$book_id,') WHERE id = $user_id";
            mysqli_query($link, $user_sql);

            echo "<script>alert('Book reserved successfully!'); window.location.href = 'home_page.php';</script>";
            exit;
        } else {
            echo "<script>alert('Book is already reserved!'); window.location.href = 'home_page.php';</script>";
            exit;
        }
    }
     /* When a user wants to reserve a book, status of book is first checked.
    If available, book is reserved and user table is updated.
*/
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home Page</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background: #f0f0f0;
        .app-bar {
            background-color: #bd4934;
            color: white;
            padding: 10px 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .app-bar a {
            color: white;
            text-decoration: none;
            margin: 0 10px;
        }
        .container {
            margin-top: 20px;
        }
        .btn-primary {
            background-color: #bd4934;
            border-color: #bd4934;
        }
        .btn-primary:hover {
            background-color: #a63c2d;
            border-color: #a63c2d;
        }
        .card {
            width: 100%;
            max-width: 500px;  
            margin-bottom: 10px; 
            padding: 15px; /* Adds space inside the element */
            border: 1px solid #ccc; /* Adds a 1px solid gray border */
            border-radius: 5px; /* Rounded corners of element */
            box-shadow: 0 0 5px rgba(0, 0, 0, 0.1); /* Adds a soft shadow around element */
        }
        .fixed-image {
            position: fixed;
            top: 60px;  
            right: 20px;
            width: 350px; 
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        .row {
            display: flex; /* Enables flexbox layout */
            flex-wrap: wrap; /* Makes items wrap to the next line */
            justify-content: flex-start; /* Aligns cards to the left */
            gap: 3px; /* Space between cards */
        }

.col {
    flex: 0 0 43%;
    max-width: 43%; 
}

.container {
    margin-right: 370px; 
    margin-left: 25px; 
}

.fixed-image {
    position: fixed;
    top: 80px;
    right: 20px;
    width: 345px;
    border-radius: 10px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
}


    </style>
</head>
<body>
    <div class="app-bar">
        <span>Book Nest App</span>
        <div>
            <a href="home_page.php">Reserve</a>
            <a href="my_reservations.php">My Reservations</a>
            <a href="index.php">Log out</a>
        </div>
    </div>
    <div class="container">
        <h2>Available Books</h2>
        <div class="row">
            <?php while ($book = mysqli_fetch_assoc($result)): ?>
                <div class="col">
                    <div class="card">
                        <div class="card-body">
                            <h5 class="card-title">Name: <?php echo htmlspecialchars($book["book_name"]); ?></h5>
                            <p class="card-text">Author: <?php echo htmlspecialchars($book["author"]); ?></p>
                            <p class="card-text">Pages: <?php echo htmlspecialchars($book["page_no"]); ?></p>
                            <p class="card-text">Status: <?php echo $book["reserved"] ? "Reserved" : "Available"; ?></p>
                            <?php if (!$book["reserved"]): ?>
                                <form method="post" class="d-inline">
                                    <input type="hidden" name="reserve_book_id" value="<?php echo $book["id"]; ?>">
                                    <button type="submit" class="btn btn-primary">Reserve</button>
                                </form>
                            <?php else: ?>
                                <button class="btn btn-secondary" disabled>Reserved</button>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            <?php endwhile; ?>
        </div>
    </div>
    <img src="/images/cat.jpg" alt="Sidebar Image" class="fixed-image">
</body>
</html>

















