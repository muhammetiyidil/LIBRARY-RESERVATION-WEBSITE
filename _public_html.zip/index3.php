<?php
session_start();
require_once "config.php";

$email = $password = "";
$email_err = $password_err = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (empty(trim($_POST["email"]))) {
        $email_err = "Please enter your email.";
    } else {
        $email = trim($_POST["email"]);
    }

    if (empty(trim($_POST["password"]))) {
        $password_err = "Please enter your password.";
    } else {
        $password = trim($_POST["password"]);
    }

    if (empty($email_err) && empty($password_err)) {
        if (isset($_POST["admin_login"])) {
            // Admins tablosunda kontrol
            $sql = "SELECT id, email, admin_password FROM admins WHERE email = ?";
        } else {
            // Users tablosunda kontrol
            $sql = "SELECT id, email, user_password FROM users WHERE email = ?";
        }

        if ($stmt = mysqli_prepare($link, $sql)) {
            mysqli_stmt_bind_param($stmt, "s", $param_email);
            $param_email = $email;

            if (mysqli_stmt_execute($stmt)) {
                mysqli_stmt_store_result($stmt);

                if (mysqli_stmt_num_rows($stmt) == 1) {
                    mysqli_stmt_bind_result($stmt, $id, $email, $db_password);

                    if (mysqli_stmt_fetch($stmt)) {
                        if ($password === $db_password) { // Şifre kontrolü
                            $_SESSION["id"] = $id;
                            $_SESSION["email"] = $email;

                            if (isset($_POST["admin_login"])) {
                                // Admin sayfasına yönlendirme
                                header("location: admin_page.php");
                            } else {
                                // User sayfasına yönlendirme
                                header("location: home_page.php");
                            }
                            exit();
                        } else {
                            $password_err = "Invalid password.";
                        }
                    }
                } else {
                    $email_err = "No account found with that email.";
                }
            } else {
                echo "Oops! Something went wrong. Please try again later.";
            }

            mysqli_stmt_close($stmt);
        }
    }
    mysqli_close($link);
}
?>

<!DOCTYPE html><!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            background: #f0f0f0;
        }
        .container {
            display: flex;
            justify-content: space-between;
            align-items: center;
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
        }
        .image-section {
            width: 40%;
            padding-right: 20px;
        }
        .image-section img {
            width: 100%;
            border-radius: 10px;
        }
        .btn-primary {
            background-color: #bd4934;
            border-color: #bd4934;
        }
        .btn-primary:hover {
            background-color: #a63c2d;
            border-color: #a63c2d;
        }
        .btn-secondary {
            background-color: #6c757d;
            border-color: #6c757d;
        }
        .btn-secondary:hover {
            background-color: #5a6268;
            border-color: #545b62;
        }
        .btn-gold {
            background-color: #ffc107;
            border-color: #ffc107;
            color: black;
        }
        .btn-gold:hover {
            background-color: #e0a800;
            border-color: #d39e00;
            color: black;
        }
        .form-section {
            width: 55%;
        }
        .button-group {
            display: flex;
            justify-content: center;
            gap: 10px;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="image-section">
            <img src="/images/Login image.jpg" alt="Login Image">
        </div>
        <div class="form-section">
            <h2 class="text-center">Login</h2>
            <p class="text-center">Please fill in your credentials to login.</p>
            <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
                <div class="mb-3">
                    <label for="email" class="form-label">Email</label>
                    <input type="email" name="email" id="email" class="form-control <?php echo (!empty($email_err)) ? 'is-invalid' : ''; ?>" value="<?php echo $email; ?>">
                    <div class="invalid-feedback"><?php echo $email_err; ?></div>
                </div>
                <div class="mb-3">
                    <label for="password" class="form-label">Password</label>
                    <input type="password" name="password" id="password" class="form-control <?php echo (!empty($password_err)) ? 'is-invalid' : ''; ?>">
                    <div class="invalid-feedback"><?php echo $password_err; ?></div>
                </div>
                <div class="button-group">
                    <button type="submit" class="btn btn-primary" name="user_login">User Login</button>
                    <button type="submit" class="btn btn-secondary" name="admin_login">Admin Login</button>
                    <a href="signup_page.php" class="btn btn-gold">Sign Up</a>
                </div>
            </form>
        </div>
    </div>
</body>
</html>
