<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<?php
// Database connection constants
define('DB_SERVER', 'localhost');
define('DB_USERNAME', 'u679098418_root');
define('DB_PASSWORD', 'Root123456*');
define('DB_NAME', 'u679098418_LIBRARY');
// Connection to the databas
$link = mysqli_connect(DB_SERVER, DB_USERNAME, DB_PASSWORD, DB_NAME);
// Check connection
if($link === false){
    die("ERROR: Could not connect. " . mysqli_connect_error());
}
?>

</body>
</html>