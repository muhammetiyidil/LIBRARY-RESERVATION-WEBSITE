<?php
session_start();
/* Code checks if user is logged in.
It retrieves user's book reservations from database.
It allows user to cancel a reservation they select.
*/
if (!isset($_SESSION["id"])) {
    header("location: signup_page.php");
    exit;
    /* User session is checked. If there is no session, it directs to signup_page.*/
}

require_once "config.php";

$user_id = $_SESSION["id"];

// Fetch reserved books for the user
$user_sql = "SELECT book_ids FROM Users WHERE id = $user_id";
$user_result = mysqli_query($link, $user_sql);
$user_data = mysqli_fetch_assoc($user_result);

// Handle empty or null book_ids
if (empty($user_data['book_ids'])) {
    $reserved_books_ids = [];
} else {
    $reserved_books_ids = explode(',', rtrim($user_data['book_ids'], ','));
}

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["cancel_book_id"])) {
    $book_id = (int)$_POST["cancel_book_id"];

    // Update the book's reserved status
    $update_sql = "UPDATE Books SET reserved = 0 WHERE id = $book_id";
    mysqli_query($link, $update_sql);

    // Remove the book from the user's book_ids
    $new_book_ids = array_diff($reserved_books_ids, [$book_id]);
    $new_book_ids_str = implode(',', $new_book_ids);

    // Update the user's book_ids
    $user_update_sql = "UPDATE Users SET book_ids = '$new_book_ids_str' WHERE id = $user_id";
    mysqli_query($link, $user_update_sql);

    echo "<script>alert('Reservation canceled successfully!'); window.location.href = 'my_reservations.php';</script>";
    exit;
      /* When user clicks the "Cancel Reservation" button, book's status is updated in books table, and reservation is removed from user.
*/
}

// Fetch reserved book details
if (!empty($reserved_books_ids)) {
    $book_ids_str = implode(',', $reserved_books_ids);
    $books_sql = "SELECT id, book_name, author, page_no FROM Books WHERE id IN ($book_ids_str)";
    $books_result = mysqli_query($link, $books_sql);
} else {
    $books_result = false;
}
/* Queries books reserved by user and gets details (book name, author, number of pages).
*/
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Reservations</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background: #f0f0f0;
        }
        .app-bar {
            background-color: #bd4934;
            color: white;
            padding: 10px 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .app-bar a {
            color: white;
            text-decoration: none;
            margin: 0 10px;
        }
        .container {
            margin-top: 20px;
            margin-right: 370px;
            margin-left: 25px;
        }
        .btn-danger {
            background-color: #bd4934;
            border-color: #bd4934;
        }
        .btn-danger:hover {
            background-color: #a63c2d;
            border-color: #a63c2d;
        }
        .card {
            width: 100%;
            max-width: 500px;
            margin-bottom: 10px;
            padding: 15px; /* Adds space inside the element */
            border: 1px solid #ccc; /* Adds a 1px solid gray border */
            border-radius: 5px; /* Rounded corners of element */
            box-shadow: 0 0 5px rgba(0, 0, 0, 0.1); /* Adds a soft shadow around element */
        }
        .fixed-image {
            position: fixed;
            top: 100px;
            right: 20px;
            width: 390px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        .row {
            display: flex; /* Enables flexbox layout */
            flex-wrap: wrap; /* Makes items wrap to the next line */
            justify-content: flex-start; /* Aligns cards to the left */
            gap: 3px; /* Space between cards */
        }
        .col {
            flex: 0 0 43%;
            max-width: 43%;
        }
    </style>
</head>
<body>
    <div class="app-bar">
        <span>Book Nest App</span>
        <div>
            <a href="home_page.php">Reserve</a>
            <a href="my_reservations.php">My Reservations</a>
            <a href="index.php">Log out</a>
        </div>
    </div>
    <div class="container">
        <h2>My Reservations</h2>
        <div class="row">
            <?php if ($books_result && mysqli_num_rows($books_result) > 0): ?>
                <?php while ($book = mysqli_fetch_assoc($books_result)): ?>
                    <div class="col">
                        <div class="card">
                            <div class="card-body">
                                <h5 class="card-title">Name: <?php echo htmlspecialchars($book["book_name"]); ?></h5>
                                <p class="card-text">Author: <?php echo htmlspecialchars($book["author"]); ?></p>
                                <p class="card-text">Pages: <?php echo htmlspecialchars($book["page_no"]); ?></p>
                                <form method="post" class="d-inline">
                                    <input type="hidden" name="cancel_book_id" value="<?php echo $book["id"]; ?>">
                                    <button type="submit" class="btn btn-danger">Cancel Reservation</button>
                                </form>
                            </div>
                        </div>
                    </div>
                <?php endwhile; ?>
            <?php else: ?>
                <p>You have no reserved books.</p>
            <?php endif; ?>
        </div>
    </div>
    <img src="/images/my_reservations.png" alt="Sidebar Image" class="fixed-image">
</body>
</html>
